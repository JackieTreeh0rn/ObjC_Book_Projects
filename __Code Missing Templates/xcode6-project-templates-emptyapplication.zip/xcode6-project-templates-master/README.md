xcode6-project-templates
========================

Xcode 6 Project Templates. Missing your "Empty Application" template?

## Installation

Simply run the install script to copy the included templates into their proper homes.

**NOTE:** The script will warn you if you don't have Xcode 6 selected using `xcode-select`.

### Manual Installation

Copy the desired templates to Xcode's project template folder:

```
.../Xcode.app/Contents/Developer/Platforms/iPhoneOS.platform/Developer/Library/Xcode/Templates/Project Templates/iOS/Application
```
